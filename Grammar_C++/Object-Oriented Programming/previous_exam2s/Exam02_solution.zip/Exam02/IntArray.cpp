#include "IntArray.h"

IntArray::IntArray(void) : m_nSize(0), m_pArr(NULL)
{
}

IntArray::IntArray(int nSize) : m_nSize(nSize)
{
	m_pArr = new int [m_nSize];

	//memset(m_pArr, 0, sizeof(int)*m_nSize);
	for(int i = 0; i < m_nSize; i++)
		m_pArr[i] = 0;
}

IntArray::IntArray(const IntArray& arr)
{
	m_nSize = arr.m_nSize;
	m_pArr = new int [m_nSize];

	//memcpy(m_pArr, arr.m_pArr, sizeof(int)*m_nSize);
	for(int i = 0; i < m_nSize; i++)
		m_pArr[i] = arr.m_pArr[i];
}

IntArray::~IntArray(void)
{
	if (m_pArr != NULL)
	{
		delete[] m_pArr;
		m_pArr = 0;
	}
}

IntArray& IntArray::operator =(const IntArray &rhs)
{
	if(m_pArr != 0)
		delete[] m_pArr;

	m_nSize = rhs.m_nSize;
	m_pArr = new int [m_nSize];

	//memcpy(m_pArr, rhs.m_pArr, sizeof(int)*m_nSize);
	for(int i = 0; i < m_nSize; i++)
		m_pArr[i] = rhs.m_pArr[i];

	return *this;
}

IntArray& IntArray::operator +=(const IntArray &rhs)
{
	if (m_nSize < rhs.m_nSize)
	{
		int *pTemp;
		int nSize = rhs.m_nSize;

		pTemp = new int [nSize];

		//memset(pTemp, 0, sizeof(int)*rhs.m_nSize);
		//memcpy(pTemp, m_pArr, sizeof(int)*m_nSize);
		for (int i = 0; i < nSize; i++)
			pTemp[i] = (i < m_nSize) ? m_pArr[i] : 0 ;

		if (m_pArr != NULL)
			delete[] m_pArr;
		m_nSize = nSize;
		m_pArr = pTemp;
	}

	for (int i = 0; i < m_nSize; i++)
		m_pArr[i] += (i < rhs.m_nSize) ? rhs.m_pArr[i] : 0;

	return *this;
}

void IntArray::Add(int idx, int val)
{
	int *pTemp;
	int nSize = m_nSize + 1;

	pTemp = new int [nSize];

	//memcpy(pTemp, m_pArr, sizeof(int)*m_nSize);
	for (int i = 0; i < idx; i++)
		pTemp[i] = m_pArr[i];

	pTemp[idx] = val;

	for (int i = idx+1; i < nSize; i++)
		pTemp[i] = m_pArr[i-1];

	if (m_pArr != NULL)
		delete[] m_pArr;
	m_nSize = nSize;
	m_pArr = pTemp;
}

int IntArray::Remove(int val)
{
	int nRet = 0;

	for (int i = 0; i < m_nSize; i++)
		if (m_pArr[i] == val) 
			nRet++;

	int *pTemp;
	int nSize = m_nSize - nRet;

	pTemp = new int[nSize];

	int idx = 0;
	for (int i = 0; i < m_nSize; i++)
		if (m_pArr[i] != val)
			pTemp[idx++] = m_pArr[i];

	if (m_pArr != NULL)
		delete[] m_pArr;
	m_nSize = nSize;
	m_pArr = pTemp;

	return nRet;
}

void IntArray::RemoveAll() 
{ 	
	if (m_pArr != NULL) 
	{
		delete[] m_pArr;
		m_pArr = NULL; 
	}
	m_nSize = 0; 
}


IntArray operator+(const IntArray& lhs, const IntArray& rhs)
{
	IntArray temp(lhs.m_nSize + rhs.m_nSize);

	for (int i = 0; i < lhs.m_nSize; i++)
		temp.m_pArr[i] = lhs.m_pArr[i];
	
	for (int i = 0; i < rhs.m_nSize; i++)
		temp.m_pArr[lhs.m_nSize+i] = rhs.m_pArr[i];

	return temp;

//	IntArray temp(lhs);
//	temp += rhs;
//	return temp;
}

std::ostream& operator<<(std::ostream& out, const IntArray& rhs)
{
	for (int i = 0; i < rhs.m_nSize; i++)
		out << rhs.m_pArr[i] << " ";

	return out;
}