#pragma once

#include <ostream>

class IntArray
{
	friend IntArray operator+(const IntArray& lhs, const IntArray& rhs);
	friend std::ostream& operator<<(std::ostream& out, const IntArray& rhs);

private:
	int *m_pArr;
	int m_nSize;

public:
	IntArray(void);
	IntArray(int nSize);
	IntArray(const IntArray& arr);

	~IntArray(void);

	IntArray& operator=(const IntArray& rhs);
	IntArray& operator+=(const IntArray& rhs);
	int& operator[](int idx) { return m_pArr[idx]; }

	int GetSize() const { return m_nSize; }
	void Add(int idx, int val);
	int Remove(int val);
	void RemoveAll();
};

IntArray operator+(const IntArray& lhs, const IntArray& rhs);
std::ostream& operator<<(std::ostream& out, const IntArray& rhs);

