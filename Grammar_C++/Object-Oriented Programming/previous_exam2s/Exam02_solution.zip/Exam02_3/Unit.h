#include <iostream>
using namespace std;

class Unit
{
protected:
	int energy;
	int attackPoint;
	int speed;
public:
	Unit() {};
	Unit(int _energy, int _ap, int _speed) : energy(_energy),attackPoint(_ap),speed(_speed) {};
	virtual void toggleSpecialSkill() { };

	virtual void speedUpgrade() { 
		speed++;
		cout << "## Speed upgraded to " << speed << "\n";
	};
	virtual void energyUpgrade() { 
		energy++;
		cout << "## Energy upgraded to " << energy << "\n";
	};
	virtual void printUnitInfo() const { 
		cout << "Energy: " << energy << " Attack Point: " << attackPoint << " speed: " << speed; };
	virtual void moveTo(int * position) {};
};

class LandUnit : public Unit
{
protected:
	int position[2];
public:
	LandUnit(int _energy, int _ap, int _speed, int x, int y) : Unit(_energy,_ap,_speed) {
		position[0] = x;
		position[1] = y;
	};
	virtual void moveTo(int * _position) {
		position[0] = _position[0]; position[1] = _position[1];
		cout << "## Unit now moved to " << position[0] << ", " << position[1] << endl;
	};
	virtual void printUnitInfo() const {
		cout << " position (x,y): " << position[0] << "," << position[1];
	};
};

class FlyingUnit : public Unit
{
protected:
	int position[3];
public:
	FlyingUnit(int _energy, int _ap, int _speed, int x, int y, int z) : Unit(_energy,_ap,_speed) {
		position[0] = x;
		position[1] = y;
		position[2] = z;
	};
	void moveTo(int * _position) {
		position[0] = _position[0]; position[1] = _position[1]; position[2] = _position[2];
		cout << "## Unit now moved to " << position[0] << ", " << position[1] << ", " << position[2] << endl;
	};
	virtual void printUnitInfo() const {
		cout << " position (x,y,z): " << position[0] << "," << position[1] << "," << position[2];
	};

};

class Marine : public LandUnit
{
private:
	bool isSteamPack;
public:
	Marine() : LandUnit(5,3,2,10,40) {
		isSteamPack = false;
	};

	virtual void toggleSpecialSkill() { 
		isSteamPack = !isSteamPack;
		if(isSteamPack) {
			isSteamPack = true;
			energy--;
			attackPoint = attackPoint + 2;
			cout << "## Steam pack shot. An energy point consumed, but attack point increased by 2.\n";
		} else {
			isSteamPack = false; 
			attackPoint = attackPoint - 2;
			cout << "## Steam pack stoped. Attack point decreased by 2.\n";
		}
	};

	virtual void printUnitInfo() const { 
		cout << "-------- Infomation : Marine -------- \n";
		Unit::printUnitInfo();
		LandUnit::printUnitInfo();
		cout << " Steam pack: " << isSteamPack << "\n\n";
	}
};

class SiegeTank : public LandUnit
{
private:
	bool isSiegeMode;
public:
	SiegeTank() : LandUnit(10,15,4,30,70) {
		isSiegeMode = false;
	};
	virtual void toggleSpecialSkill() { 
		isSiegeMode = !isSiegeMode; 
		cout << "## siege mode ";
		if(isSiegeMode) {
			attackPoint = attackPoint*2;
			cout << "on. Attack point doubled.\n";
		} else {
			attackPoint = attackPoint/2;
			cout << "off. Attack point reduced by half.\n";
		}
	};
	virtual void speedUpgrade() { 
		speed = speed + 2; 
		cout << "## Speed upgraded to " << speed << endl;
	};
	virtual void energyUpgrade() { 
		energy = energy + 3; 
		cout << "## Energy upgraded to " << energy << endl;
	};
	virtual void printUnitInfo() const { 
		cout << "-------- Information : Siege tank -------- \n";
		Unit::printUnitInfo();
		LandUnit::printUnitInfo();
		cout << " siege mode: " << isSiegeMode << "\n\n";
	}
};

class Wraith : public FlyingUnit
{
private:
	bool isCloaked;
public:
	Wraith() : FlyingUnit(50,6,8,300,50, 20) {
		isCloaked = false;
	};
	virtual void toggleSpecialSkill() { 
		isCloaked = !isCloaked; 
		cout << "## Cloaking is ";
		if(isCloaked) {
			cout << "on.\n";
		} else {
			cout << "off.\n";
		}
	};
	virtual void speedUpgrade() { 
		speed = speed + 3;
		cout << "## Speed upgraded to " << speed << endl;
	};
	virtual void energyUpgrade() { 
		energy = energy + 2; 
		cout << "## Energy upgraded to " << energy << endl;
	};
	virtual void printUnitInfo() const { 
		cout << "-------- Information : Wraith -------- \n";
		Unit::printUnitInfo();
		FlyingUnit::printUnitInfo();
		cout << " Cloaking: " << isCloaked << "\n\n";
	}
};

class BattleCruiser : public FlyingUnit
{
private:
	int numYamatoCannon;
public:
	BattleCruiser() : FlyingUnit(150,20,4,350,450,30) {
		numYamatoCannon = 10;
	};
	virtual void toggleSpecialSkill() {
		numYamatoCannon--;
		cout << "## Yamato cannon fired.\n";
	};
	virtual void speedUpgrade() { 
		speed = speed + 2; 
		cout << "## Speed upgraded to " << speed << endl;
	};
	virtual void energyUpgrade() { 
		energy = energy + 5;
		cout << "## Energy upgraded to " << energy << endl;
	};
	virtual void printUnitInfo() const { 
		cout << "-------- Information : Battle cruiser -------- \n";
		Unit::printUnitInfo();
		FlyingUnit::printUnitInfo();
		cout << " Remaining yamato cannon: " << numYamatoCannon << "\n\n";
	}
};
