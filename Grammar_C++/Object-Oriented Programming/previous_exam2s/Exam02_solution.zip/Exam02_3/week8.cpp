#include <iostream>
#include "Unit.h"
using namespace std;

int main() {
	Unit *myUnit[3];
	int position[3];
	
	//create 3 different units
	myUnit[0] = new Marine();
	myUnit[1] = new SiegeTank();
	myUnit[2] = new BattleCruiser();
	
	for(int u = 0; u < 3; u++) {
		myUnit[u]->printUnitInfo();
		if(u == 0) {
			position[0] = 30; position[1] = 120;
		} else if(u == 1) {
			position[0] = 45; position[1] = 320;
		} else if(u == 2) {
			position[0] = 400; position[1] = 125; position[2] = 30;
		}
		myUnit[u]->moveTo(position);
		myUnit[u]->energyUpgrade(); 
		myUnit[u]->speedUpgrade();
		myUnit[u]->toggleSpecialSkill();
		myUnit[u]->printUnitInfo();
	}
	return 0;
}
