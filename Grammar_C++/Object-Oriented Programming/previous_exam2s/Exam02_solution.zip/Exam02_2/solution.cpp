#include <iostream>
#include <cstdlib>

using namespace std;

#define MAXROWS 5
#define MAXCOLUMNS 10
#define MAXLINELENGTH 80

typedef struct mapitem
{
   int row,column;
   char * line;
};

typedef struct mapitem * pmapitem;
typedef pmapitem row[MAXCOLUMNS];
typedef row * gridtype[MAXROWS];

int main(int argc, char* argv[])
 {
        gridtype grid;
        pmapitem tempitem;
        int rowindex,colindex;

        for (rowindex=0;rowindex < MAXROWS; rowindex++) {

                grid[rowindex]=(row *)new row;
                for (colindex=0;colindex < MAXCOLUMNS;colindex++)
                {
                    tempitem = (pmapitem)new pmapitem;
                    tempitem->row= rowindex;
                    tempitem->column= colindex;

                    tempitem->line = (char *)new char[MAXLINELENGTH+1] ;
                    *tempitem->line ='\0';
                    *(grid[rowindex])[colindex] = tempitem;
                }
        }


    strcpy((*grid[0][0])->line,"Top Left Corner");
    strcpy((*grid[MAXROWS-1][0])->line,"Bottom Left Corner");
    strcpy((*grid[0][MAXCOLUMNS-1])->line,"Top Right Corner");
    strcpy((*grid[MAXROWS-1][MAXCOLUMNS-1])->line,"Bottom Right Corner");

    cout<<((*grid[0][0])->line)<<endl;
    cout<<((*grid[MAXROWS-1][0])->line)<<endl;
    cout<<((*grid[0][MAXCOLUMNS-1])->line)<<endl;
    cout<<((*grid[MAXROWS-1][MAXCOLUMNS-1])->line)<<endl;

    return 0;
}

