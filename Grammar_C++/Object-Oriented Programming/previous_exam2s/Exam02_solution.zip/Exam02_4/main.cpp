#include <iostream>
using namespace std;

const int MAX_PRODUCTS=100;
const int MAX_PRODUCT_NAME = 20;
const int MAX_CUSTOMER_NAME = 10;
const int MAX_PAYMENT_NAME = 20;

struct Product {
	char name[MAX_PRODUCT_NAME+1];
	int price;
	int nSales;
};

struct Customer {
	int cust_id;
	char *name;
	int points;
	bool updated;
};

struct Payment {
	char name[MAX_PAYMENT_NAME+1];
	int rate;
};

struct Basket {
	int basket_id;
	int cust_id;
	int nItems;
	char payment[MAX_PAYMENT_NAME+1];
	struct Item {
		char productName[MAX_PRODUCT_NAME+1];
		int num;
	} *items;
};

void getProductList(Product *products[])
{
	int nProducts, i;
	cin >> nProducts;
	for (i = 0; i < nProducts; i++) {
		products[i] = new Product;
		cin >> products[i]->name;
		cin >> products[i]->price;
		products[i]->nSales = 0;
	}
	products[i] = NULL;
}

void getCustomerList(Customer **customers, int *nCustomers)
{
	cin >> *nCustomers;
	*customers = new Customer[*nCustomers];
	for (int i = 0; i < *nCustomers; i++) {
		char name[MAX_CUSTOMER_NAME+1];
		cin >> (*customers)[i].cust_id >> name >> (*customers)[i].points;
		(*customers)[i].name = new char[strlen(name)+1];
		strcpy((*customers)[i].name, name);
		(*customers)[i].updated = false;
	}
}

void getPointPaymentList(Payment **payments, int &nPayments)
{
	cin >> nPayments;
	*payments = new Payment[nPayments];
	for (int i = 0; i < nPayments; i++) {
		cin >> (*payments)[i].name >> (*payments)[i].rate;
	}
}

bool getBasket(Basket& aBasket)
{
	cin >> aBasket.basket_id;
	if (aBasket.basket_id == 0) return false;
	cin >> aBasket.cust_id >> aBasket.payment >> aBasket.nItems;
	aBasket.items = new Basket::Item[aBasket.nItems];
	for (int i = 0; i < aBasket.nItems; i++) {
		cin >> aBasket.items[i].productName >> aBasket.items[i].num;
	}
	return true;
}

Product* findProduct(Product *products[], char *name)
{
	for (int i = 0; products[i] != NULL; i++) 
		if (strcmp(products[i]->name, name) == 0) return products[i];
}

Customer* findCustomer(Customer customers[], int nCustomers, int cust_id)
{
	for (int i = 0; i < nCustomers; i++)
		if (customers[i].cust_id == cust_id) return &customers[i];
}

Payment* findPayment(Payment payments[], int nPayments, char *name)
{
	for (int i = 0; i < nPayments; i++)
		if (strcmp(payments[i].name, name) == 0) return &payments[i];
}

int main()
{

	Product *products[MAX_PRODUCTS+1]; // array of pointers, each of which points to a product	
	Customer *customers; // array of customers
	Payment *payments; // array of payments
	Basket aBasket;
	int nCustomers, nPayments;

	getProductList(products); // The array has NULL value after the last product.
	getCustomerList(&customers, &nCustomers);
	getPointPaymentList(&payments, nPayments);

	int todayTotal = 0;
	cout << "### �ٱ��� �Ǹž� ###" << endl;
	while (getBasket(aBasket)) {
		int basketTotal=0, basketPoints;
		for (int i = 0; i < aBasket.nItems; i++) {
			Product *aProduct = findProduct(products, aBasket.items[i].productName);
			aProduct->nSales += aBasket.items[i].num;
			basketTotal += aProduct->price * aBasket.items[i].num;
		}
		Payment *aPayment = findPayment(payments, nPayments, aBasket.payment);
		basketPoints = basketTotal * aPayment->rate / 100;
		Customer *aCustomer = findCustomer(customers, nCustomers, aBasket.cust_id);
		aCustomer->points += basketPoints;
		aCustomer->updated = true;
		cout << "�ٱ��� " << aBasket.basket_id << ": (������: " << aCustomer->name 
			<< ", �Ѿ�: " << basketTotal << ", ����Ʈ: " << basketPoints << ")" << endl;
		todayTotal += basketTotal;
		delete [] aBasket.items;
	}
	cout << "�Ѿ�: " << todayTotal << endl;

	cout << endl << "### ���� ����Ʈ ���� ���� ###" << endl;
	for (int i = 0; i < nCustomers; i++)
		if (customers[i].updated) 
			cout << customers[i].cust_id << " " << customers[i].name << " " << customers[i].points << endl;

	cout << endl << "### ��ǰ�� �Ǹŷ� ###" << endl;
	for (int i = 0; products[i] != NULL; i++)
		if (products[i]->nSales != 0)
			cout << products[i]->name << " " << products[i]->nSales << endl;

	// free memory
	for (int i = 0; products[i] != NULL; i++)
		delete products[i];
	for (int i = 0; i < nCustomers; i++)
		delete [] customers[i].name;
	delete [] customers;
	delete [] payments;

	return 0;
}

#if 0
struct Product {
	// fill up the members
	// use static array for the product name
};

struct Customer {
	// fill up the members 
	// use a pointer for the customer name
};

const int MAX_PRODUCTS=100;

Product* findProduct(Product *products[], char *name);
Customer* findCustomer(Customer customers[], int nCustomers, int cust_id);
Payment* findPayment(Payment payments[], int nPayments, char *name);

int main()
{

	Product *products[MAX_PRODUCTS+1]; // array of pointers, each of which points to a product	
	Customer *customers; // array of customers
	Payment *payments; // array of payments
	Basket aBasket;
	int nCustomers, nPayments;

	getProductList(products);
	getCustomerList(&customers, &nCustomers);
	getPointPaymentList(&payments, nPayments);

	while (getBasket(aBasket)) 
	{
	}

	return 0;
}
#endif