#include "Sequence.h"
#include <iostream>
#include <cstring>

using namespace std;

Sequence::Sequence(int items[], int len)
{
	m_seq = new int[len];
	for (int i = 0; i < len; i++)
		m_seq[i] = items[i];
	m_len = len;
}

Sequence::Sequence(const Sequence& other)
{
	m_len = other.m_len;
	m_seq = new int[other.m_len];
	memcpy(m_seq, other.m_seq, sizeof(int)*m_len);
}

Sequence::~Sequence()
{
	delete [] m_seq;
}

bool Sequence::IsArithmetic()
{
	int d = m_seq[1] - m_seq[0];
	for (int i = 2; i < m_len; i++)
		if (d != (m_seq[i] - m_seq[i-1])) return false;
	return true;
}

bool Sequence::IsGeometric()
{
	double r = m_seq[1] / (double) m_seq[0];
	for (int i = 2; i < m_len; i++)
		if (r != (m_seq[i] / (double) m_seq[i-1])) return false;
	return true;
}

void Sequence::Concatenate(const Sequence& other)
{
	int *old_seq = m_seq;
	int old_len = m_len;
	m_len = old_len + other.m_len;
	m_seq = new int[m_len];
	memcpy(m_seq, old_seq, sizeof(int)*old_len);
	memcpy(m_seq+old_len, other.m_seq, sizeof(int)*other.m_len);
}

void Sequence::Print()
{
	char *type;

	if (IsArithmetic()) type = "��������";
	else if(IsGeometric()) type = "������";
	else type = "��Ÿ����";

	cout << "���� ����: " << type << endl;
	cout << "���� ��: ";
	for (int i = 0; i < m_len; i++)
		cout << m_seq[i] << " ";
	cout << endl;
}