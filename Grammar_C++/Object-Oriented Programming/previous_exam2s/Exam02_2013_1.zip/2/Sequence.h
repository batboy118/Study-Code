#ifndef __SEQUENCE_H__
#define __SEQUENCE_H__

class Sequence {
private:
	int *m_seq;
	int m_len;
	bool IsArithmetic();
	bool IsGeometric();
public:
	Sequence(int items[], int len);
	Sequence(const Sequence& other);
	~Sequence();
	void Concatenate(const Sequence& other);
	void Print();
};

#endif