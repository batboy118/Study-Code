#include <iostream>
#include "Sequence.h"

using namespace std;

int main()
{
	int arithmetic_seq_items[] = {1, 3, 5, 7, 9};
	int geometric_seq_items[] = {1, 2, 4, 8, 16};

	Sequence s1(arithmetic_seq_items, sizeof(arithmetic_seq_items)/sizeof(int));
	Sequence s2(geometric_seq_items, sizeof(geometric_seq_items)/sizeof(geometric_seq_items[0]));

	cout << "### Sequence 1" << endl;
	s1.Print();

	cout << "### Sequence 2" << endl;
	s2.Print();

	Sequence s3(s1);
	s3.Concatenate(s2);

	cout << "### Sequence 3" << endl;
	s3.Print();

	return 0;
}