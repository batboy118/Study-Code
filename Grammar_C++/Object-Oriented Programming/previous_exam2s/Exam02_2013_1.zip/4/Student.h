#ifndef __STUDENT_H__
#define _STUDENT_H__

#include <iostream>
#include <cstring>

using namespace std;

const int MAX_NAME_LEN = 20;
typedef char Name[MAX_NAME_LEN+1];

enum Year {FIRST=1, SECOND, THIRD, FOURTH};

class Student {
private:
	Name m_name;
	Year m_year;
	static int m_numStudents;
public:
	Student(Name s_name, Year s_year) 
	{strcpy_s(m_name, s_name); m_year = s_year; m_numStudents++; }
	~Student() { m_numStudents--;}
	void Print() 
	{cout << "�̸�: " << m_name << ", " << "�г�: " << m_year << endl; }
	static int GetNumStudents() {return m_numStudents;}
};

#endif