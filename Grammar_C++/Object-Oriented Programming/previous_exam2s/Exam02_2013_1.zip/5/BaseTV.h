
#ifndef BASETV_
#define BASETV

class BaseTV {

protected:
	char *mBrandName; //��ǥ
	int mPrice;		//����
	int mScreenSize; //ȭ�� ũ�� inch����

public:
	BaseTV();
	~BaseTV();
	virtual void printTVInfo();
	void setBrandName(char *BrandName);
	
	void setPrice(int Price)
	{
		mPrice = Price;
	}
	
	void setScreenSize(int ScreenSize)
	{
		mScreenSize = ScreenSize;
	}

	
};

#endif