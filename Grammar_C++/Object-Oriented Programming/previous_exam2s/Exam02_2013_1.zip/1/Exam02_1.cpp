#include <iostream>
using namespace std;

int factorial(unsigned int input);
void printFactorial(unsigned int *_inputArray, int *_factArray, int size);

int main()
{
	unsigned int input = 0;
	int max;
	int factResult=1;
	int inputSize=0;

	cout << "�Է� �ִ� ���� : ";
	cin >> max;

	unsigned int *inputArray = new unsigned int[max];
	int *factArray = new int[max];


	while(factResult)
	{
		if(factResult && inputSize < max)
		{
			cout << "���� ������ �Է��ϼ���. :";
			cin >> input;
			factResult = factorial(input);

			inputArray[inputSize] = input;
			factArray[inputSize] = factResult;
			inputSize ++;
		}
		else
		{
			if(!factResult)
				cout << input << "�� ���丮���� ������� �ƴմϴ�."<<endl;
			cout << endl;
			printFactorial(inputArray, factArray, inputSize);
			break;
		}
	}

	delete [] inputArray;
	delete [] factArray;

	return 0;
}

int factorial(unsigned int input)
{
	unsigned int fact = 1;
	int n=1;
	while(input!=fact)
	{
		if(fact > input)
			return 0;
		
		n++;
		fact = fact*n;
	}
	return n;
}

void printFactorial(unsigned int *_inputArray, int *_factArray, int size)
{
	int i;
	for(i=0; i<size; i++)
	{
		cout << _inputArray[i] <<"�� "<< _factArray[i] << "! �Դϴ�. "<<endl;
	}
}