#include <iostream>
using namespace std;

#include "BusinessCard.h"

BusinessCard::BusinessCard() 
{
	affiliate = NULL;
	name = NULL;
	this->s_num++;
}

BusinessCard::~BusinessCard() 
{
	cout << "�Ҹ��� ȣ�� - " << s_num << " ��° ������ �����Ǿ����ϴ�" << endl;
	s_num--;
}

BusinessCard::BusinessCard(char* i_aff, char* i_name, int i_tel)
{
	affiliate = NULL;
	name = NULL;
	input(i_aff, i_name, i_tel);
	this->s_num++;
}

BusinessCard::BusinessCard(const BusinessCard& bc) 
{
	affiliate = NULL;
	name = NULL;
	input(bc.affiliate, bc.name, bc.telNum);
	this->s_num++;
}

void BusinessCard::input(char* i_aff, char* i_name, int i_tel)
{	
	affiliate = i_aff;
	name = i_name;
	telNum = i_tel;
}

void BusinessCard::view() const
{
	cout << "��ȣ: " << s_num << " / " <<
		"�Ҽ�: " << affiliate << " / " << 
		"�̸�: " << name << " / " << 
		"Tel: " << telNum << endl;
}
	