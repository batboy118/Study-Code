#include <iostream>
#include <ctime>
#include <stdlib.h>

using namespace std;

void randomarr(int arr[], int size);
void sortarr(int arr[] , int size);
int comparr(int arr1[], int arr2[], int size);

int main()
{
	int arr[5]; // random arr
	int inputarr[5]; // user input;
	int result; // ���� ����

	randomarr(arr,5);
	cout << "������ �迭 : " ;
	for(int i = 0 ; i < 5; i++)
	{
		cout << arr[i] << " ";
	}
	cout << endl;

	sortarr(arr,5);
	cout << "---Sorting---" << endl;
	cout << "���ĵ� �迭 : ";
	for(int i = 0 ; i < 5; i++)
	{
		cout << arr[i] << " ";
	}
	cout << endl;

	cout << "5���� ���� �Է��Ͽ� �ּ��� : ";
	for(int i = 0 ; i < 5; i++)
	{
		cin >> inputarr[i];
	}

	cout << "�Էµ� �迭 : ";
	for(int i = 0 ; i < 5; i++)
	{
		cout << inputarr[i] << " ";
	}
	cout << endl;

	result = comparr(arr,inputarr,5);
	cout << "���� ������ " << result << "�� �Դϴ�." << endl;

	return 0;
};


void randomarr(int arr[], int size)
{
	srand((unsigned)time(NULL));

	int r = 0;
	for(int i = 0; i < size; i++)
	{
		r = rand()%40+1;
		arr[i] = r;
		
		// �ߺ� �˻�
		for(int j = 0 ; j < i; j ++)
		{
			if(arr[j] == r)
			{
				// �ߺ��Ǹ� i�� �ϳ� �� ���� ���Ѽ� �ٽ� �� ����
				i--;
				break;
			}
		}
	}
}

void sortarr(int arr[], int size)
{
	int minindex = 0;
	for(int i = 0 ; i < size-1; i++)
	{
		minindex = i;
		for(int j = i+1; j < size; j++)
		{
			if(arr[minindex] > arr[j])
			{
				minindex = j;
			}
		}
		int temp = arr[minindex];
		arr[minindex] = arr[i];
		arr[i] = temp;
	}
}

int comparr(int arr[] , int arr2[] , int size)
{
	int result = 0;
	for(int i = 0; i< size; i++)
	{
		for(int j = 0; j < size; j++)
		{
			if(arr[i] == arr2[j])
			{
				result++;
			}
		}
	}
	return result;
}