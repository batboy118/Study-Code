#include "SalineSolution.h"
#include <iostream>

using namespace std;

SalineSolution SalineSolution::operator+(const SalineSolution &other)
{
	return SalineSolution(_solutionWeight + other._solutionWeight, _saltWeight + other._saltWeight);
}

SalineSolution& SalineSolution::operator=(const SalineSolution &other)
{
	_solutionWeight = other._solutionWeight;
	_saltWeight = other._saltWeight;

	return *this;
}

void SalineSolution::Print(void)
{
	cout << "�ұݹ��� ��: " << _solutionWeight << "g" << endl;
	cout << "��: " << _saltWeight*100./_solutionWeight << "%" << endl;
}

SalineSolution operator+(const SalineSolution &one, const int saltWeight)
{
	return SalineSolution(one._solutionWeight + saltWeight, saltWeight);
}