#ifndef __SALINESOLUTION__
#define __SALINESOLUTION__

class SalineSolution {
private:
	int _solutionWeight;
	int _saltWeight;
public:
	SalineSolution(int solutionWeight, float concentration)
		: _solutionWeight(solutionWeight), _saltWeight(solutionWeight*concentration/100) {}
	SalineSolution(int solutionWeight, int saltWeight) 
		: _solutionWeight(solutionWeight), _saltWeight(saltWeight) {}
	SalineSolution operator+(const SalineSolution &other);
	SalineSolution& operator=(const SalineSolution &other);
	void Print(void);
	friend SalineSolution operator+(const SalineSolution& oneSolution, const int saltWeight);
};
#endif