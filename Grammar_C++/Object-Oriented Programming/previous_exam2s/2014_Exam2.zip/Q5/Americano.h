#ifndef AMERICANO_H
#define AMERICANO_H

#include "Espresso.h"

class Americano : public Espresso
{
	Americano()
	{
		strcpy(description, "�Ƹ޸�ī��");
	}

	int GetCost()
	{
		return 2000;
	}
};

#endif