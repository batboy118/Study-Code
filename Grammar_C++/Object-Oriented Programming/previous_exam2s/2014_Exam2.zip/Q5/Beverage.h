#ifndef BEVERAGE_H
#define BEVERAGE_H

#include <string>
using namespace std;

class Beverage
{
public:
	Beverage()
	{
		strcpy(description, "���� ����");
	}

	virtual ~Beverage()
	{

	}

	virtual char *GetDescription()
	{
		return description;
	}

	virtual int GetCost()
	{
		return 0;
	}

protected:
	char description[1024];
};

#endif


/*
#undef BEVERAGE_H

#ifndef BEVERAGE_H
#define BEVERAGE_H

#include <string>
using namespace std;

class Beverage
{
public:
	Beverage()
	{
		strcpy(description, "���� ����");
	}

	~Beverage()
	{

	}

	char *GetDescription()
	{
		return description;
	}

	int GetCost()
	{
		return 0;
	}

protected:
	char description[1024];
};

#endif
*/
