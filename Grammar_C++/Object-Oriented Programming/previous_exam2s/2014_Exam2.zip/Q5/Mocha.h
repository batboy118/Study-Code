#ifndef MOCHA_H
#define MOCHA_H

#include "Condiment.h"

class Mocha : public Condiment
{
public:
	Mocha(Beverage *bever) : Condiment(bever)
	{
		strcpy(description, bever->GetDescription());
		strcat(description, " + ��ī");
	}

	char *Getdescription()
	{
		return description;
	}

	int GetCost()
	{
		return 800 + bever->GetCost();
	}
};

#endif