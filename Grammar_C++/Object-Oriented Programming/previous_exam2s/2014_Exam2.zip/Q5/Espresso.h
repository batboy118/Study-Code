#ifndef ESPRESSO_H
#define ESPRESSO_H

#include "Beverage.h"

class Espresso : public Beverage
{
public:
	Espresso()
	{
		strcpy(description, "����������");
	}

	int GetCost()
	{
		return 1800;
	}
};

#endif