#include <iostream>
using namespace  std;

#include "Espresso.h"
#include "Americano.h"
#include "HouseBlend.h"
#include "Mocha.h"
#include "Whipping.h"
#include "Milk.h"
#include "Water.h"

void Display(Beverage *beverage);

void main()
{
	Beverage *bever = new Espresso();
	Display(bever);
	delete bever;

	bever = new Espresso();
	bever = new Water(bever);
	Display(bever);
	delete bever;

	bever = new HouseBlend();
	bever = new Mocha(bever);
	bever = new Whipping(bever);
	Display(bever);
	delete bever;

	bever = new HouseBlend();
	bever = new Milk(bever);
	bever = new Whipping(bever);
	bever = new Whipping(bever);
	Display(bever);
	delete bever;
}


void Display(Beverage *beverage)
{
	cout << beverage->GetDescription() << ", " << beverage->GetCost() << "��" << endl;
}


