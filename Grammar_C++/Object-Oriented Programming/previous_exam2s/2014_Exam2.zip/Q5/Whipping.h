#ifndef WHIPPING_H
#define WHIPPING_H

#include "Condiment.h"

class Whipping : public Condiment
{
public:
	Whipping(Beverage *bever) : Condiment(bever)
	{
		strcpy(description, bever->GetDescription());
		strcat(description, " + ����");
	}

	char *Getdescription()
	{
		return description;
	}

	int GetCost()
	{
		return 500 + bever->GetCost();
	}
};

#endif