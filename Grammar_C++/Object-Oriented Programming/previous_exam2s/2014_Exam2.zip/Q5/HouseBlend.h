#ifndef HOUSEBLEND_H
#define HOUSEBLEND_H

#include "Beverage.h"

class HouseBlend : public Beverage
{
public:
	HouseBlend()
	{
		strcpy(description, "�Ͽ콺 ������ Ŀ��");
	}

	int GetCost()
	{
		return 2500;
	}
};

#endif