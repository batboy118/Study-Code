#ifndef MILK_H
#define MILK_H

#include "Condiment.h"

class Milk : public Condiment
{
public:
	Milk(Beverage *bever) : Condiment(bever)
	{
		strcpy(description, bever->GetDescription());
		strcat(description, " + ����");
	}

	char *Getdescription()
	{
		return description;
	}

	int GetCost()
	{
		return 700 + bever->GetCost();
	}
};

#endif