#ifndef WATER_H
#define WATER_H

#include "Condiment.h"

class Water : public Condiment
{
public:
	Water(Beverage *bever) : Condiment(bever)
	{
		strcpy(description, bever->GetDescription());
		strcat(description, " + ��");
	}

	char *Getdescription()
	{
		return description;
	}

	int GetCost()
	{
		return 200 + bever->GetCost();
	}
};

#endif