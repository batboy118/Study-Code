#ifndef CONDIMENT_H
#define CONDIMENT_H

#include "Beverage.h"

class Condiment : public Beverage
{
public:
	Condiment(Beverage *bever)
	{
		this->bever = bever;
	}

	virtual ~Condiment()
	{
		delete bever;
	}

protected:
	Beverage *bever;
};

#endif




/*
#undef CONDIMENT_H


#ifndef CONDIMENT_H
#define CONDIMENT_H

#include "Beverage.h"

class Condiment : public Beverage
{
public:
	Condiment(Beverage *bever)
	{
		this->bever = bever;
	}

	~Condiment()
	{
		
	}

protected:
	Beverage *bever;
};

#endif
*/