
#ifndef __SOLUTION_H__
#define __SOLUTION_H__

#include <iostream>

using namespace std;

class Solution {
public:	
	enum SoluteType {SALT = 1, SUGAR, COFFEE};

private:
	int _sWeight;
	float _concentration;
	SoluteType _type;
public:
	Solution(int solutionWeight, float concentration, SoluteType type=SALT) 
		: _sWeight(solutionWeight), _concentration(concentration), _type(type) {};
	SoluteType GetSolute(void) { return _type;}
	float GetConcentration(void) { return _concentration;}
	void Print(void) { char *typeStrings[4] = {"", "SALT", "SUGAR", "COFFEE"}; 
		cout << "(����:" << typeStrings[(int)_type] << ", ��: " << _concentration << "%, ����: " << _sWeight << "g)" << endl; }
};
#endif