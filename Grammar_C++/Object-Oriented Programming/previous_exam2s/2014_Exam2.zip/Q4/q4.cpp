#include <iostream>
#include "solution.h"

using namespace std;

int main()
{
	Solution solutions[5] = {Solution(100, 10, Solution::SALT), Solution(150, 15, Solution::SUGAR), 
		Solution(70, 10, Solution::COFFEE), Solution(200, 5), Solution(170, 20, Solution::COFFEE)};

	int choice;
	float concentration;
	cout << "���� (1: SALT, 2: SUGAR, 3: SALT, 4: ANY) : ";
	cin >> choice;
	cout << "�ּ� �� : ";
	cin >> concentration;
	
	int i;
	for (i = 0; i < sizeof(solutions)/sizeof(solutions[0]); i++) {
		if ((choice == 4 || choice == solutions[i].GetSolute()) && solutions[i].GetConcentration() >= concentration) 
			solutions[i].Print();
	}
	return 0;
}