#include <iostream>
#include "Histogram.h"

using namespace std;

Histogram::Histogram(int data_ary[], int num_items, int num_intervals)
{
	_num_intervals = num_intervals;
	_counts = new int[num_intervals];

	// get min and max
	int i;
	int min = data_ary[0];
	int max = data_ary[0];
	for (i = 1; i < num_items; i++) {
		if (data_ary[i] < min)
			min = data_ary[i];
		else if (data_ary[i] > max)
			max = data_ary[i];
	}

	_min = min;
	_interval_size = (max - min + 1) / num_intervals;
	
	// get counts
	for (i = 0; i < num_intervals; i++)
		_counts[i] = 0;
	for (i = 0; i < num_items; i++)
		_counts[(data_ary[i]-min)/_interval_size]++;
}

Histogram::Histogram(const Histogram &other)
{
	_num_intervals = other._num_intervals;
	_min = other._min;
	_interval_size = other._interval_size;
	_counts = new int[_num_intervals];

	for (int i = 0; i < _num_intervals; i++)
		_counts[i] = other._counts[i];	
}

void Histogram::print() const
{
	for (int i = 0; i < _num_intervals; i++) {
		cout << _min + (_interval_size * i) << " - " 
			<< _min + (_interval_size * (i+1)) - 1 << ": " << _counts[i] << endl;
	}
}

Histogram::~Histogram()
{
	delete [] _counts;
}