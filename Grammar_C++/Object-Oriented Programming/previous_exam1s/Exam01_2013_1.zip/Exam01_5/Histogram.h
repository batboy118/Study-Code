class Histogram {
private:
	int _num_intervals;
	int _min;
	int _interval_size;
	int *_counts;
public:
	Histogram(int data_ary[], int num_items, int num_intervals);
	Histogram(const Histogram& other);
	~Histogram();
	void print() const;

	friend void AddHistograms(const Histogram&, const Histogram&);
};