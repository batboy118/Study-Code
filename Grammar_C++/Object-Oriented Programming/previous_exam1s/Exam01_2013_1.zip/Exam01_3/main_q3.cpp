#include <iostream>

using namespace std;

void reverseOrder(int seq[], int seq_len)
{
	for (int i = 0, j = seq_len - 1; i < j; i++, j--) {
		int temp = seq[i];
		seq[i] = seq[j];
		seq[j] = temp;
	}
}

int findFirstSequence(int seq[], int seq_len, int* &result_seq_ptr)
{
	int i;
	// skip decreasing part
	for (i = 1; (i < seq_len) && (seq[i-1] > seq[i]); i++);

	if (i >= seq_len) return 0;

	result_seq_ptr = &seq[i-1];
	for (i++; (i < seq_len) && (seq[i-1] <= seq[i]); i++);

	return &seq[i] - result_seq_ptr;
}

int main()
{
	cout << "������ ũ��: ";
	int num_items;
	cin >> num_items;

	cout << "����: ";
	int *seq = new int[num_items];
	for (int i = 0; i < num_items; i++)
		cin >> seq[i];

	int *start_ptr = seq;
	int *found_seq;
	int found_seq_len;
	while ((found_seq_len = findFirstSequence(start_ptr, seq+num_items-start_ptr, found_seq)) != 0) {
		reverseOrder(found_seq, found_seq_len);
		start_ptr = found_seq + found_seq_len;
	}

	// print the result
	cout << "��ȯ�� ����: ";
	for (int i = 0; i < num_items; i++)
		cout << seq[i] << " ";
	cout << endl;

	return 0;
}