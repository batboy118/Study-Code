
#include<iostream>
using namespace std;

#define MAX 5
class CStack
{
private :
	int data[MAX];
	int index;
public:
	CStack() : index(0) {}
	void push(int mdata);
	int pop();
};

void CStack::push(int mdata)
{
	data[index++] = mdata;
	if(index == MAX)
	{
		throw "Push OutOfRange";
	}
}
int CStack::pop()
{
	if(index == 0)
	{
		throw "Pop OutOfRange";
	}
	return data[--index];
	

}
int main()
{
	CStack NewStack;
	int i=0;
	for(i=0; i<10; i++)
	{
		try
		{
			NewStack.push(i);
		}
		catch(char* err)
		{
			cout << err << endl;
			break;
		}
	}
	for(i=0; i<10; i++)
	{
		try
		{
			cout << NewStack.pop() << endl;
		}
		catch(char* err)
		{
			cout << err << endl;
			break;
		}
	}
	return 0;
}
