
#include <iostream>
#include <fstream>
#include <time.h>

using namespace std;

int main()
{
	int pArr[10];
	srand((unsigned int)time(NULL));
	for (int i=0; i<10; i++)   //�ΰ��� ����Ʈ�� ����ȭ�� �� ����
	{
		pArr[i] = rand() %100 +1;
	}

	fstream fs1;
	fs1.open("Ex04_06.dat",ios::out | ios::trunc | ios::binary);
	if(!fs1)
	{
		cerr << "Output file open failure\a\n";
		exit(100);
	}	
	for(int i=0; i<10; i++)
	{
		cout << pArr[i] <<endl;
		fs1.write((char*) &(pArr[i]), sizeof(int));
	}

	fs1.close();
	fstream fs2;
	fs2.open("Ex04_06.dat" , ios::in | ios::binary);
	if(!fs2){
		cerr << "Output file open failure\a\n" ;
		exit(100);
	}
	int num[10];
	int i=0;
	for(int i=0; i<10; i++)
	{
		fs2.read((char*)& num[i], sizeof(int));
		cout << "["<<i <<"] " << num[i] <<endl;
	}
	int idx=1;
	int data;
	while(idx)
	{
		cin>>idx;
		if(idx == 0)
			return 0;
		fstream fs3;
		fs3.open("Ex04_06.dat", ios::in | ios::binary);

		fs3.seekg(idx*sizeof(int),ios::beg);
	
		fs3.read((char*)&data, sizeof(int));
	
		cout << "Index: " << idx <<endl;
		cout << "Data; " << data <<endl;

	}
	return 0;
}
