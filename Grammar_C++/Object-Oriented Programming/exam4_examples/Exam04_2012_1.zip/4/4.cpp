
#include <iostream>
using namespace std;

template <class Type>
class CSort
{
public:
	CSort(Type* Arr,int size)
	{
		m_pData= Arr;
		m_nSize = size;
	}
	void Swap(Type* num1, Type* num2)
	{
		Type temp;
		if(*num1> *num2)
		{
			temp = *num2;
			*num2 = *num1;
			*num1 = temp;
		}
	}
	void Sorting()
	{
		for(int i=0; i<m_nSize-1; ++i)
		{
			for(int j=i+1; j<m_nSize; ++j)
			{
				Swap(&m_pData[i],&m_pData[j]);
			}
		}
	}
private:
	Type* m_pData;
	int m_nSize;
};
void main()
{
	int a[10] = {1,9,6,5,3,2,0,8,7,4};
	CSort<int> sortInt(a,10);
	cout << "Integer Sort" << endl;
	sortInt.Sorting();
	for(int i=0; i<10; ++i)
		cout << a[i] << " ";
	cout << endl;

	double b[10] = {1.5,9.3,6.6,5.4,3.2,2.1,0.5,8.8,7.2,4.9};
	CSort<double> sortDouble(b,10);
	cout << "Double Sort" << endl;
	sortDouble.Sorting();
	for(int i=0; i<10; ++i)
		cout << b[i] << " ";
	cout << endl;
}
