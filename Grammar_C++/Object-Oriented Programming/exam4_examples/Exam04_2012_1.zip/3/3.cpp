
#include <iostream>
using namespace std;

enum TYPE{AIRCON, TV};
enum WIND{ LOW, MIDDLE, HIGH};
class Remocon
{
public:
	virtual void power () =0;
	virtual void up() =0;
	virtual void down() =0;
};
class FuncKey
{
public:
	virtual void func1() =0;
	virtual void func2() =0;
	virtual void func3() =0;
};

class Aircon : public Remocon , public FuncKey
{
private:
	int curTemp;
	WIND curWind;
public:
	Aircon()
	{
		curTemp = 25;
		curWind = MIDDLE;
	}
	virtual void power()
	{
		cout << "Air conditional is off " <<endl;
		exit(100);
	}
	virtual void up()
	{
		curTemp++;
		if(curTemp>27)
		{
			cout << "�ְ� �µ��� �Ѿ����ϴ�." <<endl;
			curTemp--;
		}
	}
	virtual void down()
	{
		curTemp--;
		if(curTemp <18)
		{
			cout << "���� �µ��� �Ѿ����ϴ� " << endl;
			curTemp++;
		}
	}
	virtual void func1()
	{
		curWind=LOW;
	}
	virtual void func2()
	{
		curWind=MIDDLE;
	}
	virtual void func3()
	{
		curWind=HIGH;
	}
	void print()
	{
		if(curWind==LOW)
			cout << "STATUS:Aircon | Temperature : " << curTemp << " | Wind : " <<"LOW" << endl; 
		else if(curWind==MIDDLE)
			cout << "STATUS:Aircon | Temperature : " << curTemp << " | Wind : " <<"MIDDLE" << endl; 
		else if(curWind==HIGH)
			cout << "STATUS:Aircon | Temperature : " << curTemp << " | Wind : " <<"HIGH" << endl; 
	}

};
class Television : public Remocon , public FuncKey
{
private:
	int curChannel;
	int curVolume, tempVolume;
	bool isMute;
public:
	Television()
	{
		curChannel =10;
		curVolume = 10;
		isMute = false;
	}
	virtual void power()
	{
		cout << "TV is off " <<endl;
		exit(100);
	}
	virtual void up()
	{
		curChannel ++;
		if(curChannel>99){
			cout << "�ִ� ä���� �Ѿ����ϴ� " << endl;
			curChannel--;
		}
	}
	virtual void down()
	{
		curChannel --;
		if(curChannel<0){
			cout << "�ּ� ä���� �Ѿ����ϴ� " << endl;
			curChannel++;
		}
	}
	virtual void func1()
	{
		curVolume--;
		if(curVolume < 0 )
		{
			cout << "�ּ� ������ �Ѿ����ϴ� " << endl;
			curVolume++;
		}
	}
	virtual void func2()
	{
		curVolume++;
		if(curVolume >50)
		{
			cout << "�ְ� ������ �Ѿ����ϴ� " << endl;
			curVolume--;
		}
	}
	virtual void func3()
	{
		if(!isMute)
		{
			tempVolume = curVolume;
			curVolume=0;
			isMute = true;
		}
		else
		{
			curVolume = tempVolume;
			isMute = false;
		}

	}
	void print()
	{
		cout << "STATUS:TV | Channel : " << curChannel << " | Volume : " << curVolume << endl; 
	}
};

int main()
{
	Aircon ac;
	Television tv;
	int input, inputBtn;
	TYPE type;

	cout << "Turn on [1]Air conditioner or [2]Television: ";
	cin >> input;

	if(input ==1) type=AIRCON;
	else type = TV;

	cout << "Choose button:\n [1]Poweroff\n [2]Up\n [3]Down\n [4]Func1\n [5]Func2\n [6]Func3\n";
	
	while(1)
	{
		cout<<"Command ";
		cin >> inputBtn;
		if(type == AIRCON)
		{
			switch(inputBtn)
			{
			case 1:
				ac.power();
				break;
			case 2:
				ac.up();
				break;
			case 3:
				ac.down();
				break;
			case 4:
				ac.func1();
				break;
			case 5:
				ac.func2();
				break;
			case 6:
				ac.func3();
				break;
			}
			ac.print();
		}
		else
		{
			switch(inputBtn)
			{
			case 1:
				tv.power();
				break;
			case 2:
				tv.up();
				break;
			case 3:
				tv.down();
				break;
			case 4:
				tv.func1();
				break;
			case 5:
				tv.func2();
				break;
			case 6:
				tv.func3();
				break;
			}
			tv.print();
		}
		
	}
	return 0;
}
