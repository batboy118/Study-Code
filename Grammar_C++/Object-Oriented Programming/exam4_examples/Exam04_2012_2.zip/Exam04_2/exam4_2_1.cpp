#include <cstdlib>
#include <new>
#include <iostream>

using namespace std;

class Exception{
public:
	const int* address;
	int arrayIndex;
	const char* description;
	int code;

	Exception(const int* address,int arrayIndex, const char* description, int code)
	{
		this->address=address;
		this->arrayIndex = arrayIndex;
		this->description=description;
		this->code=code;
	}
};

int main()
{
	int num[4];
	
	try{
		cout<<"1.start a test\n";

		num[10]=123;

		throw Exception(num, 10, "out of bounds",1);
		
		cout<<"this code will be printed if no exception!\n";
	}
	catch(Exception& e)
	{
		cout<<"2.exception array address : " << e.address << endl;
		cout<<"2.exception array Index : " << e.arrayIndex << endl;
		cout<<"2.exception type : " << e.description << endl;
		cout<<"2.exception code : " << e.code << endl;
	}

	cout << "3.finish a test!\n";
	cout << num[10] << endl;

	return 0;
}

