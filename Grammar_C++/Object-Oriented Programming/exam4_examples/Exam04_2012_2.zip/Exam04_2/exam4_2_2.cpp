#include <iostream>
#include <stack>
#include <string>

using namespace std;

struct syntax_error{};

int main()
{
	string exp;
	cout<< "Input the expression: " ;
	cin>>exp;

	try
	{
		stack<char> stack;
		size_t cnt(0);
		for(std::string::iterator it=exp.begin(); it != exp.end(); it++)
		{
			switch(*it)
			{
			case '(':
				stack.push(*it);
				break;
			case ')':
				if(stack.size()>0)
				{
					stack.pop();
					cnt++;
				}else{
					throw syntax_error();
				}
				break;
			default:
				break;
			}
		}

		if(stack.size()>0)
			throw syntax_error();
		else
			cout<<cnt<<endl;
	}
	catch(syntax_error)
	{
		cout<<"Syntax error"<<endl;
	}
}