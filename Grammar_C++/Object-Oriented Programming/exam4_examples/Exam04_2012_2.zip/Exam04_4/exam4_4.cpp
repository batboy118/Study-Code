#include <iostream>
#include <iomanip>
#include <ctime>
using namespace std;

template <class T>
class CMatrix
{
public:
    CMatrix( int rows=4, int cols=4)
    {
        row = rows;
        col = cols;

        data = new T*[rows];

        for (int i = 0; i < row; i++) {
            data[i] = new T [cols];
        }

        for(int i = 0; i < row; i++) {
            for(int j = 0; j < cols; j++) {
                data[i][j] = (T) (rand()%100);
            }
        }
    }

    void print();
	int getRow() {return row;}
	int getCol() {return col;}
	CMatrix<T>& operator=( const CMatrix<T>& cp );
	CMatrix<T> operator+( const CMatrix<T>& m) const;

private:
    T **data;
    int row,col;
};


template <class T>
CMatrix<T> CMatrix<T>::operator+(const CMatrix<T> &m) const {
   if(m.row != row || m.col != col ) {
      cout << "CMmatrix operator +, dimension doesn't match\n";
	  return *this;
   }
	CMatrix<T> result = (*this);
	
   for(int i=0;i<row;i++)
	   for(int j=0;j<col;j++)
			result.data[i][j] += m.data[i][j];
	return result;
}





template<class T>
CMatrix<T>& CMatrix<T>::operator=( const CMatrix<T>& cp )
{
   if(cp.row != row && cp.col != col ) {
      cout << "CMmatrix operator =, dimension doesn't match\n";
	  return *(this);
   }
   for(int i=0;i<row;i++)
	   for(int j=0;j<col;j++)
			data[i][j] = cp.data[i][j];
   return *this;
}


template <class T>
void CMatrix<T>::print ()
{
    int i,j;
	cout << row << 'x' << col << "Matrix:\n";
	cout << setprecision(2);
	cout << fixed;
	cout << showpoint;
    for (i=0;i < row;i++) {
        for(j=0;j < col;j++) {
            cout << setw(3) << data[i][j] << ' ';
        }
		cout << endl;
    }
	cout << endl;
}


void CMatrix<float>::print ()
{
    int i,j;
	cout << row << 'x' << col << " Float matrix:\n";
	cout << setprecision(2);
	cout << fixed;
	cout << showpoint;
    for (i=0;i < row;i++) {
        for(j=0;j < col;j++) {
            cout << setw(6) << data[i][j] << ' ';
        }
		cout << endl;
    }
	cout << endl;
}



int main()
{
	srand((unsigned int)time(NULL));

	CMatrix <int> iMat[2];
	cout << "Two integer random matrices\n";
	for(int i = 0;i<2;i++) {
		iMat[i].print();
	}
	CMatrix<int> iMatAnswer = iMat[1] + iMat[0];
	cout << "Sum of two\n";
	iMatAnswer.print();

    CMatrix <float> fMat[2];
	cout << "Two float random matrices\n";
	for(int i = 0;i<2;i++) {
		fMat[i].print();
	}
	CMatrix<float> fMatAnswer = fMat[1] + fMat[0];
	cout << "Sum of two\n";
	fMatAnswer.print();

	cout << "Error handling example\n";
	CMatrix<int> a(3,3), b(4,4);
	a = b + a;

    return 0;
}