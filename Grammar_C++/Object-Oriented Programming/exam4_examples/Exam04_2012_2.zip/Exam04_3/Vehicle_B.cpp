#include <iostream>
#include <fstream>
#include "Vehicle_B.h"

using namespace std;

void Vehicle_B::print(void) const {
	cout << "Model: " << m_model << endl;
	cout << "Year: " << m_year << endl;
}

void Bus_B::print(void) const {
	cout << "[BUS_B]" << endl;
	Vehicle_B::print();
	cout << "COLOR: " << m_color << endl;
	cout << "Number of PASSENGERS: " << m_passengers << endl;
}

void Truck_B::print(void) const {
	cout << "[TRUCK_B]" << endl;
	Vehicle_B::print();
	cout << "LOAD: " << m_truckload << endl;
}

void Vehicle_B::printToFile(fstream& file) const {
	file << "Model: " << m_model << endl;
	file << "Year: " << m_year << endl;
}

void Bus_B::printToFile(fstream& file) const {
	file << "[BUS_B]" << endl;
	Vehicle_B::printToFile(file);
	file << "COLOR: " << m_color << endl;
	file << "Number of PASSENGERS: " << m_passengers << endl;
}

void Truck_B::printToFile(fstream& file) const {
	file << "[TRUCK_B]" << endl;
	Vehicle_B::printToFile(file);
	file << "LOAD: " << m_truckload << endl;
}


void Bus_B::printToFile_BlockIO(fstream& file) const {
	file.write((char*)this, sizeof(*this));
}

void Truck_B::printToFile_BlockIO(fstream& file) const {
	file.write((char*)this, sizeof(*this));
}