#include <cstring>

#ifndef SIZE_DEFS
int const MAX_MODEL_NAME = 20;
int const MAX_COLOR_NAME = 10;
#define SIZE_DEFS
#endif

class Vehicle {
private:
	char m_model[MAX_MODEL_NAME+1];
	int m_year;
public:
	Vehicle() {m_model[0] = '\0'; m_year = 0;}
	Vehicle (char const* model, int const year)
		: m_year(year) {strcpy_s(m_model, model);}
	void print(void) const;
};

class Bus : public Vehicle {
private:
	char m_color[MAX_COLOR_NAME+1];
	int m_passengers;
public:
	Bus() {}
	Bus(char* model, int year, char const* color, int passengers)
		: Vehicle(model, year), m_passengers(passengers) {strcpy_s(m_color, color);}
	void print(void) const; 
};

class Truck: public Vehicle {
private:
	float m_truckload;
public:
	Truck() {}
	Truck(char* model, int const year, float truckload)
		: Vehicle(model, year), m_truckload(truckload) {}
	void print(void) const;
};
