#include <iostream>
#include "Vehicle_A.h"

using namespace std;

void Vehicle::print(void) const {
	cout << "Model: " << m_model << endl;
	cout << "Year: " << m_year << endl;
}

void Bus::print(void) const {
	cout << "[BUS]" << endl;
	Vehicle::print();
	cout << "COLOR: " << m_color << endl;
	cout << "Number of PASSENGERS: " << m_passengers << endl;
}

void Truck::print(void) const {
	cout << "[TRUCK]" << endl;
	Vehicle::print();
	cout << "LOAD: " << m_truckload << endl;
}