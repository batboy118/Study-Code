#include <iostream>
#include <cstring>

using namespace std;

#ifndef SIZE_DEFS
int const MAX_MODEL_NAME = 20;
int const MAX_COLOR_NAME = 10;
#define SIZE_DEFS
#endif

class Vehicle_B {
private:
	char m_model[MAX_MODEL_NAME+1];
	int m_year;
public:
	Vehicle_B (char const* model, int const year)
		: m_year(year) {strcpy_s(m_model, model);}
	virtual void print(void) const;	
	virtual void printToFile(fstream&) const;	
	virtual void printToFile_BlockIO(fstream&) const = 0;
};

class Bus_B : public Vehicle_B {
private:
	char m_color[MAX_COLOR_NAME+1];
	int m_passengers;
public:
	Bus_B(char const* model, int const year, char const* color, int passengers)
		: Vehicle_B(model, year), m_passengers(passengers) {strcpy_s(m_color, color);}
	void print(void) const; 	
	void printToFile(fstream&) const;
	void printToFile_BlockIO(fstream&) const;
};

class Truck_B: public Vehicle_B {
private:
	float m_truckload;
public:
	Truck_B(char const* model, int const year, float truckload)
		: Vehicle_B(model, year), m_truckload(truckload) {}
	void print(void) const;	
	virtual void printToFile(fstream&) const;
	void printToFile_BlockIO(fstream&) const;
};
