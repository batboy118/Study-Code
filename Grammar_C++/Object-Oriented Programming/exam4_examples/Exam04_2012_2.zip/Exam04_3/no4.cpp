﻿#include <iostream>
#include <cstring>
#include <fstream>
#include "Vehicle_A.h"
#include "Vehicle_B.h"

using namespace std;

void fn_a(void)
{
    Bus bigBus("KHM-B1000", 2012, "blue", 45);
    Truck smallTruck("KHM-T0500", 2011, 1.5);

	bigBus.print(); // print bus information
    smallTruck.print(); // print truck information
}

void fn_b(Vehicle_B const* v)
{
	v->print();
}

void fn_c(char const* filename, Vehicle_B const* v)
{
	fstream out(filename, ios::out);
	if (!out) {
		cout << filename << " creation failed!!!" << endl;
		exit(1);
	}

	v->printToFile(out);
	cout << filename << " created sucessfully in text mode." << endl;
	out.close();
}

void fn_d(char const* filename, Bus buses[], int num)
{
	fstream inout(filename, ios::binary | ios::out | ios::in);
	if (!inout) {
		cout << filename << " creation failed!!!" << endl;
		exit(1);
	}
	inout.write((char*)buses, num*sizeof(Bus));

	/*
	inout.close();

	inout.open(filename, ios::binary | ios::in);
	if (!inout) {
		cout << filename << " open failed!!!" << endl;
		exit(1);
	}
	*/

	inout.seekg((num-3)*sizeof(Bus), ios::beg);
	Bus b;
	inout.read((char*)&b, sizeof(Bus));
	inout.close();
	b.print();
	cout << filename << " created sucessfully in binary mode." << endl;
}

int main()
{
	cout << "Question (a)" << endl;
	fn_a();

	cout << endl << "Question (b)" << endl;
	Bus_B bigBus("KHM-B1000", 2012, "blue", 45);
	Truck_B smallTruck("KHM-T0500", 2011, 1.5);
	fn_b(&bigBus);
	fn_b(&smallTruck);

	cout << endl << "Question (c)" << endl;
	fn_c("exam04_4.txt", &bigBus);

	cout << endl << "Question (d)" << endl;
	Bus buses[] = {Bus("KHM-B1000", 2012, "blue", 45), 
		Bus("KHM-B1050", 2012, "red", 30), Bus("KHM-B1060", 2011, "white", 30),
		Bus("KHM-B3050", 2010, "red", 50), Bus("KHM-B2060", 2010, "black", 60)};
	fn_d("exam04_4.bin", buses, sizeof(buses)/sizeof(Bus));

	cout << endl << "Question (e)" << endl;
	cout << "Answers are here." << endl; 

	return 0;
}