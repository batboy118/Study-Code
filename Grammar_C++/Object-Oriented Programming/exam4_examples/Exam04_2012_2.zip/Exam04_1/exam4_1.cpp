#include <iostream>
#include <iomanip>
#include <string> 
#include <list>
#include <algorithm>

using namespace std;

//�ܾ�� ���� ���� �����ϴ� Ŭ����
class WordElement 
{
public:
	// constructor
	WordElement();
	WordElement(const string& str );
	// copy constructor
	WordElement(const WordElement& wc);

	// destructor
	~WordElement();

public:

	// operator overloading
	WordElement& operator++( void );			// increment word count 
	bool operator==( const string& word );		// compare the strWord to the given string(word)
												// returns true if given word and strWord are equal; otherwise false
	bool operator<( const WordElement& we );	// compare strWord to we.strWord

	// friend << operator
	friend ostream& operator<< (ostream& ostrm, const WordElement & rhs);

	// function to compare by word count
	friend bool CompareCount(const WordElement& first, const WordElement& second);

	// method 
	int getCount() const;	// get count of a word (returns nCount)

protected:
	string strWord;		// string to store a word
	int    nCount ;		// count of strWord
};


WordElement::WordElement()
{
	strWord="";
	nCount=0;
}

WordElement::WordElement(const string& str )
{
	strWord=str;
	nCount=1;
}

WordElement::WordElement(const WordElement& wc)
{
	strWord=wc.strWord;
	nCount=wc.nCount;
}

WordElement::~WordElement()
{
};

WordElement& WordElement::operator++( void )
{
	nCount++;
	return (*this);
}

bool WordElement::operator==( const string& word )
{
	return (strWord==word);
}

bool WordElement::operator<( const WordElement& wc )
{
	return (strWord<wc.strWord);
}

int WordElement::getCount() const
{
	return nCount;
}

ostream& operator<< (ostream& ostrm, const WordElement & rhs)
{
	ostrm << setw(20) << rhs.strWord << setw(5) << rhs.nCount << endl;
	return ostrm;
}

bool CompareCount(const WordElement& first, const WordElement& second)
{
	if( first.nCount == second.nCount )
		return (first.strWord < second.strWord);
	return (first.nCount > second.nCount);
}

////////////////////////

typedef list<WordElement>	LIST_WORDCOUNT;
typedef LIST_WORDCOUNT::iterator	LIST_WORDCOUNTIter;

class WordCount
{
public:
	LIST_WORDCOUNTIter findWord(const string & word);	// Find an element in the m_listWC
	// Find the position of the first occurrence of an element equals to given word in the m_listWC
	// If no such value exists in the m_listWC, returns end position of the m_listWC

	void addWord( const string& word );		// Add an element to the m_listWC
	// If an element equals to given word exists in the m_listWC, increase count of the element;
	// Otherwise, add the element to the m_listWC
	void printMostWords();					// Print the most frequently used word(s)
	void printLeastWords();					// Print the least frequently used word(s)

protected:
	LIST_WORDCOUNT m_listWC;
};

LIST_WORDCOUNTIter WordCount::findWord(const string & word)
{
//	return ::find(m_listWC.begin(), m_listWC.end(), word);
	LIST_WORDCOUNTIter iter;
	for (iter = m_listWC.begin(); iter != m_listWC.end(); iter++)
		if (*iter == word)
			return iter;

	return iter;
}

void WordCount::addWord( const string& word )
{
	LIST_WORDCOUNTIter iter = findWord(word);

	if (iter != m_listWC.end())
		++(*iter);
	else
		m_listWC.push_back( WordElement(word) );
}

void WordCount::printMostWords()
{
	m_listWC.sort(CompareCount);

	if (m_listWC.size() > 0)
	{
		LIST_WORDCOUNTIter iter = m_listWC.begin();
		
		for (int nMax = iter->getCount(); iter != m_listWC.end() && iter->getCount() == nMax; iter++)
			cout << *iter;
	}
}

void WordCount::printLeastWords()
{
	m_listWC.sort(CompareCount);

	if (m_listWC.size() > 0)
	{
//typedef LIST_WC::reverse_iterator	LIST_WC_REV_ITER; 
//		LIST_WC_REV_ITER iter = m_listWC.rbegin();
// 
// 		for (int nMin = iter->getCount(); iter != m_listWC.rend() && iter->getCount() == nMin; iter++)
// 			cout << *iter;
		LIST_WORDCOUNTIter iter = m_listWC.end();
		iter--;

		int nMin = iter->getCount();
		while(1)
		{
			if (nMin == iter->getCount())
				cout << *iter;

			if (iter == m_listWC.begin())
				break;

			iter--;
		}
	}
}

//////////////////////////

int main ( void ) 
{
	string strIn;
	WordCount wc;

 	cout << "Input string : ";

	// Input string using get_line
 	getline(cin, strIn);

	// build word count list using WordCount and strIn.
	size_t pos_find = 0;
	char *str_del = " ,\n.\"\'";

	while( 1 )
	{
		pos_find = strIn.find_first_not_of(str_del, pos_find);
		if ( pos_find == string::npos )
			break;

		size_t pos_del = strIn.find_first_of(str_del, pos_find);
		string word = strIn.substr ( pos_find, pos_del-pos_find );

		wc.addWord( word );
		pos_find = pos_del;
	}

	// print the most used word(s)
	wc.printMostWords();
	// print the least used word(s)
	wc.printLeastWords();
	
	return 0;
}

