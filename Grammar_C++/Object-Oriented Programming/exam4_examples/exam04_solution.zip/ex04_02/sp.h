class ReferenceCount
{
private:
    int mRCount; // Reference count
public:
    void AddRef(){ // ���� ���� ����
        mRCount++;
    }
    int Release(){ // ���� ���� ���� �� ���ҵ� �� ����
        return --mRCount;
    }
	ReferenceCount(){mRCount=0;}
};

template < typename Type > class SmartPointer
{
private:
    Type*    mDataPointer;       // pointer
    ReferenceCount* mReferenceCount; // Reference count

public:
    SmartPointer() : mDataPointer(0), mReferenceCount(0) 
    {
        // Create a new reference 
        mReferenceCount = new ReferenceCount();
        // Increment the reference count
        mReferenceCount->AddRef();
    }

    SmartPointer(Type* pValue) : mDataPointer(pValue), mReferenceCount(0)
    {
        // Create a new reference 
        mReferenceCount = new ReferenceCount();
        // Increment the reference count
        mReferenceCount->AddRef();
    }

    SmartPointer(const SmartPointer<Type>& sp) : mDataPointer(sp.mDataPointer), mReferenceCount(sp.mReferenceCount)
    {
        // Copy constructor
        // Copy the data and reference pointer
        // and increment the reference count
        mReferenceCount->AddRef();
    }

    ~SmartPointer()
    {
        // Destructor
        // Decrement the reference count
        // if reference become zero delete the data
        if(mReferenceCount->Release() == 0)
        {
            delete mDataPointer;
            delete mReferenceCount;
        }
    }

    Type& operator* ()
    {
        return *mDataPointer;
    }

    Type* operator-> ()
    {
        return mDataPointer;
    }
    
    SmartPointer<Type>& operator = (const SmartPointer<Type>& sp)
    {
        // Assignment operator
        if (this != &sp) // Avoid self assignment
        {
            // Decrement the old reference count
            // if reference become zero delete the old data
            if(mReferenceCount->Release() == 0)
            {
                delete mDataPointer;
                delete mReferenceCount;
            }

            // Copy the data and reference pointer
            // and increment the reference count
            mDataPointer = sp.mDataPointer;
            mReferenceCount = sp.mReferenceCount;
            mReferenceCount->AddRef();
        }
        return *this;
    }
};